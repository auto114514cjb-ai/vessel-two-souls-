import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {ImageStore,MAX_IMAGE_BYTES,trustedQQImageUrl,downloadQQImage,receiveQQImages,visionMessage} from '../images.mjs';
import {recognizeImages,visionSelection} from '../vision.mjs';import {Desk,validateConfig,DEFAULTS,codexArgs} from '../core.mjs';import {createApp} from '../server.mjs';
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jY1sAAAAASUVORK5CYII=';
const bytes=Buffer.from(png.split(',')[1],'base64');
function temp(t){const d=fs.mkdtempSync(path.join(os.tmpdir(),'souls-vision-'));t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d}
const vote=s=>JSON.stringify({note:s+' 的角色意见',treasure:{keep:true,title:'图片约定',summary:'用户讨论图片中的共同约定。',reason:'这段真实对话有意义。',tags:['图片']}});
test('image storage validates bytes, limits size and paths, and stores only opaque references in messages',t=>{
 const store=new ImageStore(temp(t)),ref=store.add(png);assert.equal(store.read(ref.id).type,'image/png');assert.equal(store.dataUrls([ref])[0],png);assert.equal(store.refs([ref.id,ref.id]).length,1);
 for(const value of ['data:image/svg+xml;base64,PHN2Zy8+','data:image/png;base64,PGh0bWw+','https://example.com/image.png'])assert.throws(()=>store.add(value));
 assert.throws(()=>store.read('../config.json'));assert.throws(()=>store.refs([{},ref.id]));assert.throws(()=>store.refs(Array(4).fill(ref.id)));assert.throws(()=>store.addBytes(Buffer.alloc(MAX_IMAGE_BYTES+1)));
});
test('QQ images use get_image and only QQ HTTPS hosts; redirects, local paths and excess bytes are rejected',async t=>{
 for(const url of ['http://gchat.qpic.cn/a','https://gchat.qpic.cn.evil.test/a','http://127.0.0.1/a','file:///private/key','https://user:password@gchat.qpic.cn/a','https://gchat.qpic.cn:8443/a'])assert.throws(()=>trustedQQImageUrl(url));
 let gets=0,downloads=0;const store=new ImageStore(temp(t)),snow={call:async(action,params)=>{gets++;assert.equal(action,'get_image');assert.equal(params.file,'file-opaque');return {url:'https://gchat.qpic.cn/image'}}};
 const refs=await receiveQQImages({message:[{type:'image',data:{file:'file-opaque'}}]},snow,store,async(url,options)=>{downloads++;assert.equal(options.redirect,'error');assert.equal(options.headers,undefined);return new Response(bytes)});
 assert.equal(gets,1);assert.equal(downloads,1);assert.equal(refs.length,1);assert.equal(store.dataUrls(refs)[0],png);
 await assert.rejects(downloadQQImage('https://gchat.qpic.cn/large',async()=>new Response(bytes,{headers:{'content-length':String(MAX_IMAGE_BYTES+1)}})),/超过/);
 await assert.rejects(receiveQQImages({message:[{type:'image',data:{file:'local'}}]},{call:async()=>({file:'file:///private/key'})},store),/未能取得/);
});
test('vision routing sends raw image data only to the vision adapter; groups never reach Codex',async t=>{
 const store=new ImageStore(temp(t)),refs=[store.add(png)],calls=[],config=validateConfig({visionBackend:'codex',visionModel:'gpt-test',visionGroupModel:'gpt-group'});
 const adapters={codex:async(v)=>{calls.push(v);assert.deepEqual(v.dataUrls,[png]);return '图中有文字：共同约定。'},chatgpt:async(v)=>{calls.push(v);return '群聊图片摘要'}};
 assert.equal((await recognizeImages(config,refs,'这是什么？',false,store,adapters)).backend,'codex');
 assert.equal((await recognizeImages(config,refs,'这是什么？',true,store,adapters)).backend,'chatgpt');assert.equal(calls[1].model,'gpt-group');
 await assert.rejects(recognizeImages({...config,visionEnabled:false},refs,'x',false,store,adapters),/已关闭/);
 const args=codexArgs({...DEFAULTS,codexModel:'gpt-test'},[store.file(refs[0].id)]);assert.ok(args.includes('read-only'));assert.ok(args.includes('features.shell_tool=false'));assert.equal(args.at(-1),'-');assert.equal(args[args.indexOf('--image')+1],store.file(refs[0].id));
});
test('one vision pass supplies labelled observations to both roles, future context and treasure image references',async t=>{
 let reads=0;const prompts=[],desk=new Desk(temp(t),{recognize:async(refs,q,group)=>{reads++;assert.equal(refs.length,1);assert.equal(group,false);return {status:'done',by:'GPT 演示',summary:'图片中写着：约定一起看星星。'}},innerChat:async(c,s,h,i)=>{prompts.push(h);return vote(s)},codex:async(c,h)=>{prompts.push(h);return '已经理解这个约定。'},deepseek:async()=>{throw new Error('只由 GPT 最终回答')}});
 desk.config=validateConfig({innerDialogue:true,treasuresEnabled:true},desk.config);const ref=desk.images.add(png),job=desk.submitComputer('GPT，图片里写了什么？','both',false,'private',[ref.id]);await desk.tail;
 assert.equal(reads,1);assert.equal(job.status,'done');assert.equal(prompts.length,3);for(const h of prompts){assert.match(h[0].text,/图片中写着/);assert.match(h[0].text,/未直接看到原图/);assert.ok(!JSON.stringify(h).includes('iVBOR'))}
 const original=desk.state.messages.find(m=>m.role==='user');assert.equal(original.text,'GPT，图片里写了什么？');assert.equal(original.attachments[0].id,ref.id);assert.ok(job.treasure);const treasure=desk.treasures.get('private',job.treasure.id);assert.equal(treasure.messages[0].attachments[0].id,ref.id);assert.match(treasure.messages[0].text,/图片中写着/);
 desk.submit('还记得刚才图片里的约定吗？','codex');await desk.tail;assert.equal(reads,1);assert.ok(prompts.at(-1).some(m=>m.text.includes('图片中写着')));
});
test('vision failure or disabled access never guesses an answer or creates an automatic treasure',async t=>{
 const desk=new Desk(temp(t),{recognize:async()=>{throw new Error('模型不支持图片')},innerChat:async()=>{throw new Error('不应开始讨论')},codex:async()=>{throw new Error('不应猜测图片')}}),ref=desk.images.add(png);
 desk.config=validateConfig({innerDialogue:true,treasuresEnabled:true},desk.config);const job=desk.submitComputer('','codex',false,'private',[ref.id]);await desk.tail;assert.equal(job.status,'failed');assert.equal(job.innerDialogue,undefined);assert.equal(job.treasure,undefined);assert.ok(!desk.state.messages.some(m=>m.role==='assistant'));assert.match(desk.state.messages.at(-1).text,/没有读取原图/);
});
test('image HTTP upload/read is session guarded and empty-text messages can carry images',async t=>{
 const {server,desk}=createApp({dataDir:temp(t),providers:{recognize:async()=>({status:'done',by:'GPT 测试',summary:'静态图片'}),codex:async()=> '图片答复'}});await new Promise(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise(r=>{server.closeAllConnections();server.close(r)}));
 const base=`http://127.0.0.1:${server.address().port}`,cookie=(await fetch(base)).headers.get('set-cookie').split(';')[0],headers={cookie,'content-type':'application/json','x-local-request':'1'};
 assert.equal((await fetch(base+'/api/images',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({dataUrl:png})})).status,401);
 const response=await fetch(base+'/api/images',{method:'POST',headers,body:JSON.stringify({dataUrl:png})});assert.equal(response.status,200);const ref=await response.json();assert.equal((await fetch(base+ref.url)).status,401);assert.equal((await fetch(base+ref.url,{headers:{cookie}})).headers.get('content-type'),'image/png');
 assert.equal((await fetch(base+'/api/images',{method:'POST',headers:{...headers,origin:'https://evil.example'},body:JSON.stringify({dataUrl:png})})).status,403);
 assert.equal((await fetch(base+'/api/chat',{method:'POST',headers,body:JSON.stringify({text:'',mode:'codex',images:[ref.id]})})).status,202);await desk.tail;assert.equal(desk.state.jobs.at(-1).vision.status,'done');
});
