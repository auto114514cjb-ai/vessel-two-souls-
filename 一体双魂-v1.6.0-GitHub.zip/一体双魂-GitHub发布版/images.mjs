import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';
export const MAX_IMAGE_BYTES=5*1024*1024,MAX_IMAGES=3;
const ID=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.(png|jpg|webp)$/;
function sniff(bytes){
 if(bytes.length>=8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return ['png','image/png'];
 if(bytes.length>=3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255)return ['jpg','image/jpeg'];
 if(bytes.length>=12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')return ['webp','image/webp'];
 throw new Error('图片需为 PNG、JPG 或 WebP；GIF 请先转成静态图片');
}
export class ImageStore{
 constructor(dataDir){this.dir=path.join(dataDir,'chat-images')}
 addBytes(bytes){if(!bytes.length||bytes.length>MAX_IMAGE_BYTES)throw new Error('每张图片最多 5 MB');const [ext,type]=sniff(bytes),id=crypto.randomUUID()+'.'+ext;fs.mkdirSync(this.dir,{recursive:true});fs.writeFileSync(path.join(this.dir,id),bytes,{mode:0o600});return {id,type,size:bytes.length,url:'/api/images/'+id}}
 add(dataUrl){if(typeof dataUrl!=='string'||dataUrl.length>7100000)throw new Error('图片内容过大或格式不正确');const m=dataUrl.match(/^data:image\/(?:png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/);if(!m)throw new Error('请选择 PNG、JPG 或 WebP 图片');const bytes=Buffer.from(m[1],'base64');if(bytes.toString('base64')!==m[1])throw new Error('图片编码不正确');return this.addBytes(bytes)}
 file(id){if(typeof id!=='string'||!ID.test(id))throw new Error('图片标识不正确');const file=path.join(this.dir,id);if(!fs.existsSync(file)||fs.lstatSync(file).isSymbolicLink())throw new Error('图片不存在');return file}
 read(id){const bytes=fs.readFileSync(this.file(id));if(bytes.length>MAX_IMAGE_BYTES)throw new Error('图片过大');const [,type]=sniff(bytes);return {bytes,type}}
 refs(ids=[]){if(!Array.isArray(ids)||ids.length>MAX_IMAGES||ids.some(id=>typeof id!=='string'))throw new Error('每条消息最多 3 张图片');return [...new Set(ids)].map(id=>{const {bytes,type}=this.read(id);return {id,type,size:bytes.length,url:'/api/images/'+id}})}
 dataUrls(refs){return refs.map(({id})=>{const {bytes,type}=this.read(id);return `data:${type};base64,${bytes.toString('base64')}`})}
}
export function imageSegments(event){return Array.isArray(event.message)?event.message.filter(s=>s.type==='image').map(s=>s.data||{}):[]}
export function trustedQQImageUrl(value){
 let u;try{u=new URL(value)}catch{throw new Error('QQ 图片地址不可用')}
 const h=u.hostname.toLowerCase();if(u.protocol!=='https:'||u.username||u.password||u.port||!(h==='multimedia.nt.qq.com'||h==='multimedia.nt.qq.com.cn'||h==='qpic.cn'||h.endsWith('.qpic.cn')||h==='qpic.com'||h.endsWith('.qpic.com')))throw new Error('只接受 QQ 图片服务器的 HTTPS 图片，不读取本机路径或任意网址');return u.href;
}
export async function downloadQQImage(url,fetchImpl=fetch){
 const safeUrl=trustedQQImageUrl(url);let response;try{response=await fetchImpl(safeUrl,{redirect:'error',signal:AbortSignal.timeout(15000)})}catch{throw new Error('QQ 图片下载失败或链接已过期，请重新发送原图')}if(!response.ok||!response.body)throw new Error('QQ 图片下载失败或链接已过期');
 if(Number(response.headers.get('content-length')||0)>MAX_IMAGE_BYTES){await response.body?.cancel();throw new Error('QQ 图片超过 5 MB')}
 const parts=[];let size=0;for await(const p of response.body){size+=p.length;if(size>MAX_IMAGE_BYTES){await response.body.cancel().catch(()=>{});throw new Error('QQ 图片超过 5 MB')}parts.push(p)}return Buffer.concat(parts);
}
export async function receiveQQImages(event,snow,store,fetchImpl=fetch){
 const segments=imageSegments(event);if(segments.length>MAX_IMAGES)throw new Error('每条消息最多识别 3 张图片');const refs=[];
 for(const seg of segments){let info={};if(typeof seg.file==='string'&&seg.file.length<=2000){try{info=await snow.call('get_image',{file:seg.file})||{}}catch{}}
  const url=[info.url,info.file,seg.url].find(v=>typeof v==='string'&&v.startsWith('https://'));
  if(typeof url!=='string'||!url.startsWith('https://'))throw new Error('未能取得 QQ 图片链接，请发送原图或重新发送图片');
  refs.push(store.addBytes(await downloadQQImage(url,fetchImpl)));
 }return refs;
}
export function visionMessage(message){
 if(message.modelReady)return message;
 if(!message.attachments?.length&&!message.vision)return message;
 const note=message.vision?.status==='done'?'图片识别摘要（由 '+message.vision.by+' 读取原图生成，可能有误；其他角色仅依据此摘要，未直接看到原图）：\n'+message.vision.summary:'本条消息含图片，但图片尚未成功识别。请明确说明没有看到图片，不要编造图中内容。';
 return {...message,modelReady:true,text:message.text+'\n<image_observation>\n'+note+'\n</image_observation>'};
}
